
if( typeof(FBSiteTrackerUri) == "undefined" || typeof(FBSiteTrackerURI) == "unknown" ) {
 var FBSiteTrackerUri = "43Folders";
 document.write('<script type="text/javascript" charset="utf-8" src="http://feeds.feedburner.com/~d/static/site-tracker.js"></script>');
}     	
    	