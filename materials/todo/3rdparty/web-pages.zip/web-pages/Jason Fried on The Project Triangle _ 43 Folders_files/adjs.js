var phpadsbanner = '';

phpadsbanner += '<'+'!-- TF 300x250 JScript NoAD code -->\n<'+'center><'+'script language=javascript><'+'!--\ndocument.write(\'<'+'scr\'+\'ipt language=javascript src="http://a.tribalfusion.com/j.ad?site=FMTech&adSpace=43Folders&size=300x250&noAd=1&requestID=\'+((new Date()).getTime() % 2147483648) + Math.random()+\'"><'+'/scr\'+\'ipt>\');\n//-->\n<'+'/script>\n<'+'noscript>\n   <'+'a target=\'_blank\' href="http://dynamic.fmpub.net/adserver/adclick.php?bannerid=2329&amp;zoneid=452&amp;source=&amp;dest=http%3A%2F%2Fa.tribalfusion.com%2Fi.click%3Fsite%3DFMTech%26adSpace%3D43Folders%26size%3D300x250%26requestID%3D600309707&amp;ismap=" \n   <'+'img src="http://a.tribalfusion.com/i.ad?site=FMTech&adSpace=43Folders&size=300x250&requestID=600309707" \n                  width=300 height=250 border=0 alt="Click Here"><'+'/a>\n<'+'/noscript>\n<'+'/center>\n<'+'!-- TF 300x250 JScript NoAD code --><'+'div id="beacon_2329" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"><'+'img src=\'http://dynamic.fmpub.net/adserver/adlog.php?bannerid=2329&amp;clientid=1875&amp;zoneid=452&amp;source=&amp;block=0&amp;capping=0&amp;cb=51e10b5599979120c4221a9c5be32511\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\'><'+'/div>';

document.write(phpadsbanner);

if (document.phpAds_used) document.phpAds_used += 'bannerid:2329,';

if (document.phpAds_used) document.phpAds_used += 'campaignid:1875,';
