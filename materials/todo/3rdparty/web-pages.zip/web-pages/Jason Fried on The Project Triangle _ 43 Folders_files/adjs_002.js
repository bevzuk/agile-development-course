var phpadsbanner = '';

phpadsbanner += '<'+'iframe src="http://view.atdmt.com/AVE/iview/fdrtdnru0310000135ave/direct/01?click=" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0" allowtransparency="true" width="125" height="125">\n<'+'script language="JavaScript" type="text/javascript">\ndocument.write(\'<'+'a href="http://clk.atdmt.com/AVE/go/fdrtdnru0310000135ave/direct/01/" target="_blank"><'+'img src="http://view.atdmt.com/AVE/view/fdrtdnru0310000135ave/direct/01/"/><'+'/a>\');\n<'+'/script><'+'noscript><'+'a href="http://clk.atdmt.com/AVE/go/fdrtdnru0310000135ave/direct/01/" target="_blank"><'+'img border="0" src="http://view.atdmt.com/AVE/view/fdrtdnru0310000135ave/direct/01/" /><'+'/a><'+'/noscript><'+'/iframe><'+'div id="beacon_5105" style="position: absolute; left: 0px; top: 0px; visibility: hidden;"><'+'img src=\'http://dynamic.fmpub.net/adserver/adlog.php?bannerid=5105&amp;clientid=4010&amp;zoneid=34&amp;source=&amp;block=0&amp;capping=0&amp;cb=8794aac5cbfa9bf67f1c2fa8e887fe3f\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\'><'+'/div>';

document.write(phpadsbanner);

if (document.phpAds_used) document.phpAds_used += 'bannerid:5105,';

if (document.phpAds_used) document.phpAds_used += 'campaignid:4010,';
