amazon_ad_o = 1;
amazon_ad_rcm = "rcm.amazon.com";
document.write("<scr"+"ipt src='http://www.assoc-amazon.com/s/ads-common.js' type='text/javascr"+"ipt'></scr"+"ipt>");
